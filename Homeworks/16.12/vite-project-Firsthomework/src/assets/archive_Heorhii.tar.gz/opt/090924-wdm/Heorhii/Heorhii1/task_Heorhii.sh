#!/bin/bash

# Получаем текущую дату в формате день.месяц.год
DATE=$(date +"%d.%m.%y")

# Получаем путь к директории, где находится скрипт
SCRIPT_DIR=$(dirname "$0")

# Создаём 10 файлов с порядковым номером и датой в той же директории
for i in {1..10}; do
    # Создаём файл с текстом "File $i created on $DATE"
    echo "File $i created on $DATE" > "$SCRIPT_DIR/${i}_${DATE}"
done

